document.addEventListener("DOMContentLoaded", function() {
    document.querySelector(".bottom-side__link").addEventListener("click", function() {
        document.querySelector(".menu-alert").classList.add("visible");
        document.querySelector(".bottom-side__link-alert").classList.add("visible-link");
        document.querySelector(".bottom-side__link").classList.add("invisible");
        
    })

    document.querySelector(".bottom-side__link-alert").addEventListener("click", function() {
        document.querySelector(".menu-alert").classList.remove("visible");
        document.querySelector(".bottom-side__link").classList.remove("invisible");
        document.querySelector(".bottom-side__link-alert").classList.remove("visible-link");
    })
})